Copyrighted � 2013 by Greg McLeod
https://github.com/cleod9

Free to use and/or modify without notifying me. Just do not re-distribute it under anyone else's name please!

-----------------------------------

About Pong for C#:

The first program I ever wrote in Visual Studio after only using it for less than a day. This is obviously not the proper way to write a pong game (nor is it particularly great coding), but it desmonstrates how simple it is to manupulate the buttons and other Window components  with C#. If you are just starting out with C#, I recommend taking a look so you can understand what you're allowed to get away with in C# :p